<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Satuan;

class SatuanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Data satuan
        $satuans = [
            [
                'kode_satuan' => 'SAT001',
                'nama_satuan' => 'Unit',
            ],
            [
                'kode_satuan' => 'SAT002',
                'nama_satuan' => 'Pcs',
            ],
            [
                'kode_satuan' => 'SAT003',
                'nama_satuan' => 'Kg',
            ],

        ];

        // Memasukkan data ke dalam tabel Satuan
        foreach ($satuans as $satuan) {
            Satuan::updateOrCreate(['kode_satuan' => $satuan['kode_satuan']], $satuan);
        }
    }
}
