<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Barang;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Data barang
        $barang = [
            [
                'kode_barang' => 'BRG001',
                'nama_barang' => 'Laptop',
                'harga_barang' => 5000000,
                'deskripsi_barang' => 'Laptop merek X',
            ],
            [
                'kode_barang' => 'BRG002',
                'nama_barang' => 'Mouse',
                'harga_barang' => 100000,
                'deskripsi_barang' => 'Mouse merek Y',
            ],
            // Tambahkan data barang lainnya jika diperlukan
        ];

        // Memasukkan data ke dalam tabel Barang
        foreach ($barang as $item) {
            Barang::create($item);
        }
    }
}
