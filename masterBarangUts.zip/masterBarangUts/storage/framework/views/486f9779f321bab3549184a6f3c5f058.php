<?php $__env->startSection('content'); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Profile Mahasiswa</div>
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item">Nama: Zulfa Azka Farisadilah</li>
                        <li class="list-group-item">NIM: 1204220109</li>
                        <li class="list-group-item">Jurusan: Sistem Informasi</li>
                        <li class="list-group-item">Angkatan: 2022</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\prakzulfa\resources\views/profile.blade.php ENDPATH**/ ?>