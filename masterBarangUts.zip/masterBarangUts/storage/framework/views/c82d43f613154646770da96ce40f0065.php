<?php $__env->startSection('content'); ?>
<?php echo $__env->make('default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1 class="display-4">Selamat Datang di Toko!</h1>
                <p class="lead">Temukan berbagai barang berkualitas dengan harga terbaik di toko kami.</p>
                <hr class="my-4">
                <p>Jelajahi koleksi barang kami dan nikmati pengalaman berbelanja yang menyenangkan.</p>
                <a class="btn btn-primary btn-lg" href="<?php echo e(route('barang.index')); ?>" role="button">Lihat Barang</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\prakzulfa\resources\views/home.blade.php ENDPATH**/ ?>