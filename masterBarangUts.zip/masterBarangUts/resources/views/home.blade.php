@extends('layouts.app')
@section('content')
@include('default')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1 class="display-4">Selamat Datang di Toko!</h1>
                <p class="lead">Temukan berbagai barang berkualitas dengan harga terbaik di toko kami.</p>
                <hr class="my-4">
                <p>Jelajahi koleksi barang kami dan nikmati pengalaman berbelanja yang menyenangkan.</p>
                <a class="btn btn-primary btn-lg" href="{{ route('barang.index') }}" role="button">Lihat Barang</a>
            </div>
        </div>
    </div>
</div>
@endsection
