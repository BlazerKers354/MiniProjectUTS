@extends('layouts.app')
@section('content')
@include('default')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Profile Mahasiswa</div>
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item">Nama: Zulfa Azka Farisadilah</li>
                        <li class="list-group-item">NIM: 1204220109</li>
                        <li class="list-group-item">Jurusan: Sistem Informasi</li>
                        <li class="list-group-item">Angkatan: 2022</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
